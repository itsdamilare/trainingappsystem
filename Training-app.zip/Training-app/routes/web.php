<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SessionController;
use App\Http\Controllers\ApplicationController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\Auth\RegisterController;




Route::get('/', [DashboardController::class, 'index'])
->name('home');





Route::get('/dashboard', [DashboardController::class, 'index'])
    ->name('dashboard');



Route::get('/profile', [ProfileController::class, 'index'])
->name('profile');


Route::post('/profile', [ProfileController::class, 'store']);



Route::post('/logout', [LogoutController::class, 'store'])->name('logout');

Route::get('/login', [LoginController::class, 'index'])->name('login');
Route::post('/login', [LoginController::class, 'store']);

Route::get('/register', [RegisterController::class, 'index'])->name('register');
Route::post('/register', [RegisterController::class, 'store']);

Route::get('/sessions', [SessionController::class, 'index'])->name('sessions');
Route::post('/sessions', [SessionController::class, 'filter']);

Route::get('/sessions/filtered', [SessionController::class, 'filter']);

Route::post('/sessions/filtered', [SessionController::class, 'filter'])->name('sessions.filter');
Route::get('/sessions/show/{id}', [SessionController::class, 'show'])->name('sessions.show');

Route::get('/sessions/apply/{id}', [SessionController::class, 'apply'])->name('sessions.apply');




Route::post('/applications/create', [ApplicationController::class, 'store'])->name('application.create');
Route::post('/applications/update', [ApplicationController::class, 'update'])->name('application.update');
Route::get('/applications/delete/{id}', [ApplicationController::class, 'destroy'])->name('application.destroy');


