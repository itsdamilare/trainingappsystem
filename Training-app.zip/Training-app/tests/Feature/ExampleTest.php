<?php

namespace Tests\Feature;

// use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use App\Models\User;



class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */

    


    public function test_the_user_cannot_access_the_dashboard_as_a_guest()
    {
        $response = $this->get('/');

        $response->assertStatus(302);
    }


   public function test_the_user_is_logged_in() 
   {
        $user = User::factory()->create();
    
        // Log in the user
        $this->actingAs($user);
    
        // Send a GET request to a protected route
        $response = $this->get('/dashboard');
        $this->assertAuthenticated();
        // Assert that the response indicates the user is authenticated
        $response->assertStatus(200);
    }

    public function test_the_user_cannot_open_login_page_when_authenticated() 
    {
         $user = User::factory()->create();
     
         // Log in the user
         $this->actingAs($user);
     
         // Send a GET request to a protected route
         $response = $this->get('/login');
         $this->assertAuthenticated();
         // Assert that the response indicates the user is authenticated
         $response->assertStatus(302);
     }


     public function test_the_user_is_successfully_logged_out() 
     { $user = User::factory()->create();
        $response = $this->actingAs($user)->post('/logout');
        $response->assertRedirect('/');
        $this->assertGuest();
      }

      public function test_the_user_has_a_department_after_registering()
      { 
      $user = User::factory()->create(['department' => 'human-resources']);
   
      $this->assertDatabaseHas('users', [
          'id' => $user->id,
          'department' => 'human-resources',
      ]);
    }
}
