<?php $__env->startSection('content'); ?>


    <div class="flex  flex-col gap-5 mb-5 justify-center">
      <div class="flex w-full  gap-1 justify-evenly">
        <div class="w-6/12 px-3 rounded-lg">
          <h3 class="w-full p-6 bg-white font-bold text-lg  rounded-lg">Applied Sessions</h3>

          <?php if($applications->count()): ?>
          <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div  class=" p-6 bg-white mt-3 break-all 	 rounded-lg">
              <h3 class="font-bold"><?php echo e($application->session->title); ?></h3>
              <h6 class="text-sm"><?php echo e($application->session->eventdate); ?></h6>
              <p class="mt-3"><?php echo e($application->session->description); ?></p>
  
   <div class="w-full flex justify-end mt-5"><a href="/sessions/show/<?php echo e($application->session->id); ?>">
   <button class="bg-sky-500 px-4 py-2 rounded-md text-white">View Details</button></a>
            </div>
          </div>
  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
  
          <p class="p-6 bg-white rounded-lg mt-6">There are no available applications.</p>
  
          <?php endif; ?>
  
          
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmomoh/Desktop/training-app/training-app/resources/views/dashboard/index.blade.php ENDPATH**/ ?>