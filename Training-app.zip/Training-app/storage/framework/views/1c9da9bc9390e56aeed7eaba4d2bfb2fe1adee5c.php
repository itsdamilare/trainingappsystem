<?php $__env->startSection('content'); ?>
    <div class="flex justify-center">
        <div class="w-8/12 bg-white p-6 rounded-lg">

                <h3 class="font-bold"><?php echo e($session->title); ?></h3>
                <h6 class="text-sm"><?php echo e($session->eventdate); ?></h6>
                <p class="mt-3"><?php echo e($session->description); ?></p>

              <div class="mt-5">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
              </div>
              <?php if($loggedIn): ?>
            <?php if($expired == 'true'): ?>

            <div class="w-full flex justify-end mt-5">

                        
                <p class="bg-gray-700 px-4 py-2 rounded-md text-white">Applications ended for this session.</p>
                         </div>
            <?php else: ?>

              <?php if($disabled == "false"): ?>
                <?php if($applied): ?>

                <div class="w-full flex justify-end mt-5">

                    <a href="/applications/delete/<?php echo e($session->id); ?>">
                 <button class="bg-red-500 px-4 mx-3 py-2 rounded-md text-white">Delete Application</button></a>

                 <a href="/sessions/apply/<?php echo e($session->id); ?>">
                    <button class="bg-green-500 px-4 py-2 rounded-md text-white">Edit Application</button></a>

                          </div>
                <?php else: ?>
                <div class="w-full flex justify-end mt-5">

                    <a href="/sessions/apply/<?php echo e($session->id); ?>">
                 <button class="bg-sky-500 px-4 py-2 rounded-md text-white">Apply</button></a>
                          </div>


                <?php endif; ?>
           
                      <?php else: ?> 
                      <div class="w-full flex justify-end mt-5">

                        
                        <p class="bg-gray-700 px-4 py-2 rounded-md text-white">Not Available for your department</p>
                                 </div>
                        <?php endif; ?>
             <?php endif; ?>
        <?php endif; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmomoh/Desktop/training-app/training-app/resources/views/sessions/show.blade.php ENDPATH**/ ?>