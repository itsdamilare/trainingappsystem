<?php $__env->startSection('content'); ?>

<div class="flex  flex-col gap-5 mb-5 justify-center">


  <div class="w-full px-3 rounded-lg">
    <div class="bg-white p-6 rounded-lg flex items-center justify-between">
         <h3 class="font-bold text-lg">Available Sessions</h3>


            <?php if($filter == "true"): ?>
            <form action="<?php echo e(route('sessions.filter')); ?>" method="post">
                <?php echo csrf_field(); ?>
            <input class="hidden" type="text" name="filter" id="filter" value="false" />
            <button type="submit" class="bg-sky-500 px-4 py-2 rounded-md text-white ">Show All Sessions</button>
        </form>
            <?php else: ?>
            <form action="<?php echo e(route('sessions.filter')); ?>" method="post">
                <?php echo csrf_field(); ?>
            <input class="hidden" name="filter" id="filter" value="true" />
            <button type="submit" class="bg-sky-500 px-4 py-2 rounded-md text-white ">Show Related Sessions</button>
        </form>
           <?php endif; ?>


    </div>


<div class="grid grid-cols-3 gap-4">
        <?php if($sessions->count()): ?>
        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div  class=" p-6 bg-white mt-3 break-all 	 rounded-lg">
            <h3 class="font-bold"><?php echo e($session->title); ?></h3>
            <h6 class="text-sm"><?php echo e($session->eventdate); ?></h6>
            <p class="mt-3"><?php echo e($session->description); ?></p>

 <div class="w-full flex justify-end mt-5"><a href="/sessions/show/<?php echo e($session->id); ?>">
 <button class="bg-sky-500 px-4 py-2 rounded-md text-white">View Details</button></a>
          </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>

        <p class="p-6 bg-white rounded-lg mt-6">There are no available sessions</p>

        <?php endif; ?>



    </div>
    </div>




    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dmomoh/Desktop/training-app/training-app/resources/views/sessions/index.blade.php ENDPATH**/ ?>