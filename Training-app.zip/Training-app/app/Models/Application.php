<?php

namespace App\Models;

use App\Models\Session;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Application extends Model
{
    use HasFactory;
    protected $table = 'application';


    protected $fillable = [
        'letter',
        'session_id',
        'user_id'
    ];


    public function session()
    {
        return $this->hasOne(Session::class, 'id', "session_id");
    }
}
