<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Models\Application;
use App\Models\Session;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
       
        $id = Auth::id();
        $applications = Application::where("user_id", $id)->with('session')->get();
      
        // $sessions = Session::whereDate('eventdate', '>', $referenceDate->subDays(7))->get();
        // $referenceDate = Carbon::now();
        // $department = User::where('id', $id)->get()->first()->department;
        // $categoryId = Category::where('category', $department)->get()->first()->id;
        // $filter = 'true';
        // if($request->filter == 'true')
        // {

        //     $sessions = $sessions->where('category', '=', $categoryId);
        // }
        // else{

        //     return redirect()->route('sessions');
        // }



        return view('dashboard.index', compact('applications'));
    }
}
