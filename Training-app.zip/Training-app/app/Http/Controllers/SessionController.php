<?php

namespace App\Http\Controllers;

use App\Models\Session;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Application;
use App\Models\Category;



class SessionController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth'])->only(['apply','filter',]);
    }

    public function index()
    {

        $referenceDate = Carbon::now();
        $sessions = Session::whereDate('eventdate', '>', $referenceDate->subDays(7))->get();
        $filter = 'false';

        // $sessions = Session::whereDate('eventdate', '>', $referenceDate->subDays(7))
        // ->whereDate('eventdate', '<', $referenceDate->addDays(7))
        // ->get();


        return view('sessions.index', [
            'sessions' => $sessions,
            'filter' => $filter,
        ]);
    }


    public function filter(Request $request)
    {

        $referenceDate = Carbon::now();
        $sessions = Session::whereDate('eventdate', '>', $referenceDate->subDays(7))->get();
        $id = Auth::id();
        $department = User::where('id', $id)->get()->first()->department;
        $categoryId = Category::where('category', $department)->get()->first()->id;
        $filter = 'true';
        if($request->filter == 'true')
        {

            $sessions = $sessions->where('category', '=', $categoryId);
        }
        else{

            return redirect()->route('sessions');
        }


        return view('sessions.index', [
            'sessions' => $sessions,
            'department' => $department,
            'filter' => $filter
        ]);
    }

    public function show(Request $request)
    {


        $session = Session::where('id', $request->id)->get()->first();
        $loggedIn = Auth::id();
        $disabled = 'true';
        $expired = 'false';
        if($loggedIn){
        if(Session::where('id', $request->id)->get()->first()->category == Category::where('category', User::where('id', $loggedIn)->get()->first()->department)->get()->first()->id)
     {
        $disabled = 'false';
     }
    }
     $applied = Application::where('user_id', $loggedIn)->where('session_id', $session->id)->get()->first();

     if(Carbon::now()->addHours(24) > $session->eventdate )
     {
        $expired = 'true';
     }
     
        return view('sessions.show', [
            'session' => $session,
            'loggedIn' => $loggedIn,
            'disabled' => $disabled,
            'applied' => $applied,
            'expired' => $expired
        ]);
    }




    public function apply(Request $request)
    {

        $loggedIn = Auth::id();
        $session = Session::where('id', $request->id)->get()->first();
       $user = User::where('id', $loggedIn)->get()->first();
        
       if(Session::where('id', $request->id)->get()->first()->category != Category::where('category', User::where('id', $loggedIn)->get()->first()->department)->get()->first()->id){
        return redirect()->route('sessions');
       }

       $applied = Application::where('user_id', $loggedIn)->where('session_id', $session->id)->get()->first();
    
   

        return view('sessions.apply', [
            'session' => $session,
            'loggedIn' => $loggedIn,
            'user' => $user,
            'applied' => $applied
        ]);
    }

}
