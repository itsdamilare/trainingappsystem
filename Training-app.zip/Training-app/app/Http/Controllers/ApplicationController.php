<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Session;
use Illuminate\Support\Facades\Auth;
use App\Models\Application;



class ApplicationController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth']);
    }



    public function store(Request $request)
    {

        $this->validate($request, [
            'letter' => 'required|max:255',
        ]);
    
        $user_id = Auth::id();

        $application = new Application();
        $application->letter = $request->letter;
        $application->user_id = $user_id;
        $application->session_id = Session::where('title', $request->session)->get()->first()->id;

        $application->save();


         return redirect()->route('dashboard');
    }


    public function update(Request $request)
    {
        $this->validate($request, [
            'letter' => 'required|max:255',
        ]);

        $user_id = Auth::id();

        Application::updateOrCreate(
            ['user_id' =>  $user_id, 'session_id' => Session::where('title', $request->session)->get()->first()->id],
            ['letter' => $request->letter]
        );

        return redirect()->route('dashboard');
    }


    public function destroy(Request $request, $id)
    {

        $user_id = Auth::id();
        $session_id = $id;

        Application::where(['user_id' =>  $user_id, 'session_id' => $session_id])->delete();
        
        return back();
    }

}
