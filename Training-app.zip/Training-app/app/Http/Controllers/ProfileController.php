<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;
use App\Models\User;



class ProfileController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth']);
    }

    public function index()
    {
        $id = Auth::id();
        $profileDetails = User::where('id', $id)->get()->first();
        $confirmationMessage = "";
        return view('profile.index', compact('profileDetails', 'confirmationMessage'));
    }


    public function store(Request $request)
    {

        $this->validate($request, [
            'name' => 'required|max:255',
            'username' => 'required|max:255',
            'department' => 'required|max:255',
            'email' => 'required|email|max:255',
        ]);


        $id = Auth::id();



        User::where('id', $id)->update( [
            'name' => $request->name,
            'username' => $request->username,
            'email' => $request->email,
            'department' => $request->department,
        ]);

        $profileDetails = User::where('id', $id)->get()->first();
        $confirmationMessage = "Your profile has been updated successfully";
        return view('profile.index', compact('profileDetails', 'confirmationMessage'));

    }

}
