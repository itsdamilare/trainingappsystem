@extends('layouts.app')

@section('content')


    <div class="flex  flex-col gap-5 mb-5 items-center	">





        <div class="w-6/12 px-3 rounded-lg">
          <h3 class="w-full p-6 bg-white font-bold text-lg  rounded-lg">My Profile</h3>


          <div  class=" p-6 bg-white mt-3 break-all	 rounded-lg">
            <form action="{{ route('profile') }}" method="post">
                @csrf
               @if($confirmationMessage)
                <div class="mb-4">
                  {{$confirmationMessage}}
                </div>
            @endif
                <div class="mb-4">
                    <label for="name" class="sr-only">Name</label>
                    <input type="text" name="name" id="name" placeholder="Your name" class="bg-gray-100 border-2 w-full p-4 rounded-lg @error('name') border-red-500 @enderror" value="{{ $profileDetails->name ?? old('name') }}">

                    @error('name')
                        <div class="text-red-500 mt-2 text-sm">
                            {{ $message }}
                        </div>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="username" class="sr-only">Username</label>
                    <input type="text" name="username" id="username" placeholder="Username" class="bg-gray-100 border-2 w-full p-4 rounded-lg @error('username') border-red-500 @enderror" value="{{ $profileDetails->username ?? old('username') }}">

                    @error('username')
                        <div class="text-red-500 mt-2 text-sm">
                            {{ $message }}
                        </div>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="email" class="sr-only">Email</label>
                    <input type="text" name="email" id="email" placeholder="Your email" class="bg-gray-100 border-2 w-full p-4 rounded-lg @error('email') border-red-500 @enderror" value="{{ $profileDetails->email ?? old('email') }}">

                    @error('email')
                        <div class="text-red-500 mt-2 text-sm">
                            {{ $message }}
                        </div>
                    @enderror
                </div>


                <div class="mb-4">
                    <label for="department" class="sr-only">Department</label>
                    <select name="department" id="department" class="bg-gray-100 border-2 w-full p-4 rounded-lg" >
                        <option {{ $profileDetails->department == "media" ? 'selected' : ""}} value="media">Media</option>
                        <option {{ $profileDetails->department == "information-technology" ? 'selected' : ""}} value="information-technology">Information Technology</option>
                        <option {{ $profileDetails->department == "human-resources" ? 'selected' : ""}} value="human-resources">Human Resources</option>
                        <option {{ $profileDetails->department == "marketing" ? 'selected' : ""}} value="marketing">Marketing</option>
                        <option {{ $profileDetails->department == "legal" ? 'selected' : ""}} value="legal">Legal</option>
                        <option {{ $profileDetails->department == "administration" ? 'selected' : ""}} value="administration">Administration</option>
                    </select>

                </div>



                <div>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-3 rounded font-medium w-full">Confirm Information</button>
                </div>
            </form>
        </div>
        </div>
    </div>


@endsection
