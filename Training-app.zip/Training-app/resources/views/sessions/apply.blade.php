@extends('layouts.app')

@section('content')
    <div class="flex justify-center">
        <div class="w-8/12 bg-white p-6 rounded-lg">
            <form action="@if($applied) {{ route('application.update')}} @else {{ route('application.create')}} @endif" method="post">
                @csrf
                <div class="mb-4">
                    <label for="name" class="sr-only">Name</label>
                    <input type="text" name="disabled_name" id="disabled_name" placeholder="Your name" disabled class="bg-gray-100 border-2 w-full p-4 rounded-lg @error('name') border-red-500 @enderror" value="{{$user->name }}">
                    <input type="text" name="name" id="name" placeholder="Your name" class="hidden" value="{{$user->name }}">

                </div>

                <div class="mb-4">
                    <label for="username" class="sr-only">Username</label>
                    <input type="text" name="disabled_username" id="disabled_username" placeholder="Username" disabled class="bg-gray-100 border-2 w-full p-4 rounded-lg @error('username') border-red-500 @enderror" value="{{ $user->username }}">

                    <input type="text" name="username" id="username" placeholder="Username" class="hidden" value="{{ $user->username }}">

                </div>

                <div class="mb-4">
                    <label for="email" class="sr-only">Email</label>
                    <input type="text" disabled name="disabled_email" id="disabled_email" placeholder="Your email" class="bg-gray-100 border-2 w-full p-4 rounded-lg @error('email') border-red-500 @enderror" value="{{ $user->email }}">

                    <input type="text" name="email" id="email" placeholder="Your email" class="hidden" value="{{ $user->email }}">

                </div>


                <div class="mb-4">
                    <label for="department" class="sr-only">Department</label>
                    <select name="disabled_department" disabled id="disabled_department" class="bg-gray-100 border-2 w-full p-4 rounded-lg">
                        <option {{ $user->department == "media" ? 'selected' : ""}} value="media">Media</option>
                        <option {{$user->department == "information-technology" ? 'selected' : ""}} value="information-technology">Information Technology</option>
                        <option {{ $user->department == "human-resources" ? 'selected' : ""}} value="human-resources">Human Resources</option>
                        <option {{ $user->department == "marketing" ? 'selected' : ""}} value="marketing">Marketing</option>
                        <option {{ $user->department == "legal" ? 'selected' : ""}} value="legal">Legal</option>
                        <option {{ $user->department == "administration" ? 'selected' : ""}} value="administration">Administration</option>
                    </select>

                    <select name="department" disabled id="department" class="hidden">
                        <option {{ $user->department == "media" ? 'selected' : ""}} value="media">Media</option>
                        <option {{$user->department == "information-technology" ? 'selected' : ""}} value="information-technology">Information Technology</option>
                        <option {{ $user->department == "human-resources" ? 'selected' : ""}} value="human-resources">Human Resources</option>
                        <option {{ $user->department == "marketing" ? 'selected' : ""}} value="marketing">Marketing</option>
                        <option {{ $user->department == "legal" ? 'selected' : ""}} value="legal">Legal</option>
                        <option {{ $user->department == "administration" ? 'selected' : ""}} value="administration">Administration</option>
                    </select>

                </div>

                <div class="mb-4">
                    <label for="session" class="sr-only">Session Name</label>
                    <input type="text" name="disabled_session" id="disabled_session" disabled placeholder="Session Name" class="bg-gray-100 border-2 w-full p-4 rounded-lg @error('username') border-red-500 @enderror" value="{{ $session->title }}">
                    <input type="text" name="session" id="session" placeholder="Session Name" class="hidden" value="{{ $session->title }}">

                   
                </div>


                <div class="mb-4">
                    <label for="letter" class="sr-only">Cover Letter</label>
                    <textarea type="text" name="letter" id="letter" placeholder="Why do you want to be part of this session?" class="bg-gray-100 border-2 w-full p-4 rounded-lg @error('letter') border-red-500 @enderror">@if($applied) {{ $applied->letter}} @endif</textarea>

                    @error('letter')
                        <div class="text-red-500 mt-2 text-sm">
                            {{ $message }}
                        </div>
                    @enderror
                </div>

            

                <div>
                    <button type="submit" class="bg-blue-500 text-white px-4 py-3 rounded font-medium w-full">Apply for Session</button>
                </div>
            </form>
            </div>
        </div>
    </div>
@endsection
