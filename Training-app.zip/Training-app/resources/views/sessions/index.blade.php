@extends('layouts.app')

@section('content')

<div class="flex  flex-col gap-5 mb-5 justify-center">


  <div class="w-full px-3 rounded-lg">
    <div class="bg-white p-6 rounded-lg flex items-center justify-between">
         <h3 class="font-bold text-lg">Available Sessions</h3>


            @if($filter == "true")
            <form action="{{ route('sessions.filter') }}" method="post">
                @csrf
            <input class="hidden" type="text" name="filter" id="filter" value="false" />
            <button type="submit" class="bg-sky-500 px-4 py-2 rounded-md text-white ">Show All Sessions</button>
        </form>
            @else
            <form action="{{ route('sessions.filter') }}" method="post">
                @csrf
            <input class="hidden" name="filter" id="filter" value="true" />
            <button type="submit" class="bg-sky-500 px-4 py-2 rounded-md text-white ">Show Related Sessions</button>
        </form>
           @endif


    </div>


<div class="grid grid-cols-3 gap-4">
        @if ($sessions->count())
        @foreach ($sessions as $session)
        <div  class=" p-6 bg-white mt-3 break-all 	 rounded-lg">
            <h3 class="font-bold">{{  $session->title}}</h3>
            <h6 class="text-sm">{{ $session->eventdate }}</h6>
            <p class="mt-3">{{$session->description}}</p>

 <div class="w-full flex justify-end mt-5"><a href="/sessions/show/{{ $session->id }}">
 <button class="bg-sky-500 px-4 py-2 rounded-md text-white">View Details</button></a>
          </div>
        </div>

        @endforeach
    @else

        <p class="p-6 bg-white rounded-lg mt-6">There are no available sessions</p>

        @endif



    </div>
    </div>




    {{-- <div class="flex justify-center">
        <div class="w-8/12 bg-white p-6 rounded-lg">
            @auth
                <form action="{{ route('sessions') }}" method="post" class="mb-4">
                    @csrf
                    <div class="mb-4">
                        <label for="body" class="sr-only">Body</label>
                        <textarea name="body" id="body" cols="30" rows="4" class="bg-gray-100 border-2 w-full p-4 rounded-lg @error('body') border-red-500 @enderror" placeholder="Post something!"></textarea>

                        @error('body')
                            <div class="text-red-500 mt-2 text-sm">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div>
                        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded font-medium">Available Sessions</button>
                    </div>
                </form>
            @endauth

            @if ($sessions->count())
                @foreach ($sessions as $session)
                    <x-session :session="$session" />
                @endforeach

                {{ $sessions->links() }}
            @else
                <p>There are no sessions</p>
            @endif
        </div>
    </div> --}}
@endsection
