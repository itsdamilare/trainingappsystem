@extends('layouts.app')

@section('content')
    <div class="flex justify-center">
        <div class="w-8/12 bg-white p-6 rounded-lg">

                <h3 class="font-bold">{{$session->title}}</h3>
                <h6 class="text-sm">{{ $session->eventdate }}</h6>
                <p class="mt-3">{{$session->description}}</p>

              <div class="mt-5">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
              </div>
              @if($loggedIn)
            @if($expired == 'true')

            <div class="w-full flex justify-end mt-5">

                        
                <p class="bg-gray-700 px-4 py-2 rounded-md text-white">Applications ended for this session.</p>
                         </div>
            @else

              @if($disabled == "false")
                @if($applied)

                <div class="w-full flex justify-end mt-5">

                    <a href="/applications/delete/{{ $session->id }}">
                 <button class="bg-red-500 px-4 mx-3 py-2 rounded-md text-white">Delete Application</button></a>

                 <a href="/sessions/apply/{{ $session->id }}">
                    <button class="bg-green-500 px-4 py-2 rounded-md text-white">Edit Application</button></a>

                          </div>
                @else
                <div class="w-full flex justify-end mt-5">

                    <a href="/sessions/apply/{{ $session->id }}">
                 <button class="bg-sky-500 px-4 py-2 rounded-md text-white">Apply</button></a>
                          </div>


                @endif
           
                      @else 
                      <div class="w-full flex justify-end mt-5">

                        
                        <p class="bg-gray-700 px-4 py-2 rounded-md text-white">Not Available for your department</p>
                                 </div>
                        @endif
             @endif
        @endif

            </div>
        </div>
    </div>
@endsection
